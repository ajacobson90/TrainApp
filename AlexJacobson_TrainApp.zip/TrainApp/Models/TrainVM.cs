﻿namespace TrainApp.Models
{
    public class TrainVM
    {
        public string Destination { get; set; }
        public TimeOnly DepartureTime { get; set; }
    }
}
