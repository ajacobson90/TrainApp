﻿namespace TrainApp.Models
{
    public class TrainSeatsVM
    {
        public string Destination { get; set; }
        public int AvailableWindowSeats { get; set; }
        public int AvailableAisleSeats { get; set; }
    }
}
